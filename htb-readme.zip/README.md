<div align="center">

# 🏴‍☠️ HTB WalkThroughs

**Hack The Box machine write-ups — from the first nmap scan to root.**
Each one explains the *why* behind every step, not just the commands.

<!-- BADGES:START -->
<!-- BADGES:END -->

</div>

---

## 📊 At a glance

<!-- STATS:START -->
<!-- STATS:END -->

## 🆕 Recently solved

<!-- RECENT:START -->
<!-- RECENT:END -->

## 🗂️ All write-ups

> Click a difficulty to expand it. Newest first.

<!-- MACHINES:START -->
<!-- MACHINES:END -->

## 🧭 How every write-up is structured

| | Phase | What you'll find |
|:-:|:--|:--|
| 1️⃣ | **Recon** | Port scans, service and web enumeration |
| 2️⃣ | **Foothold** | The vulnerability, the exploit, the first shell |
| 3️⃣ | **Privilege escalation** | Local enumeration → root / SYSTEM / Domain Admin |
| 4️⃣ | **Takeaways** | What I learned, plus detection and mitigation ideas |

## ➕ Adding a new write-up

<details>
<summary>The README updates itself — here's how</summary>

1. Create a folder named after the machine, with a `README.md` inside.
2. Start that `README.md` with the header table below.
3. Commit and push. A GitHub Action rebuilds the stats card, counts and tables above within a minute.

```markdown
# HTB Write-Up: MachineName

| Field      | Details                                                           |
|------------|-------------------------------------------------------------------|
| Platform   | [Hack The Box](https://app.hackthebox.com/machines/MachineName)   |
| Difficulty | Easy / Medium / Hard / Insane                                     |
| OS         | Linux / Windows                                                   |
| Date       | Month DD, YYYY                                                    |
```

If `Difficulty`, `OS` or `Date` are missing, the generator falls back to `scripts/overrides.csv`, and for the date to the first git commit of that folder.

</details>

---

<sub>⚠️ For educational purposes only. Please follow Hack The Box's rules on publishing write-ups.</sub>
